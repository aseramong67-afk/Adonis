if CLIENT then
	game.AddParticles("particles/blood_impact.pcf")
	game.AddParticles("particles/antlion_blood.pcf")
   -- game.AddParticles("particles/water_impact.pcf")
	
	PrecacheParticleSystem("blood_impact")
	PrecacheParticleSystem("antlion_blood")
	
end
print("Half-Life/Goldsrc Blood Particles loaded!")
